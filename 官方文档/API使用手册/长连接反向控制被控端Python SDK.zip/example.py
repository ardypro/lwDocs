# coding=utf-8
__author__ = 'wuyong'

from leweisocket import leweisocket

host = "tcp.lewei50.com"
port  = 9960
userkey = "用户Key"
gatewayNo = "您的网关号"

#定义消息回调函数
#参数: socket 连接对象,josn 字符串转为对象,原始json 串
def msg_handler(lewei_socket,obj,json_str):
    print json_str #打印原始json串

    if obj["f"]=='writeSerial': #接收到写串口指令
        print 'recv writeSerial command ,  send result!!!'
        #发送模拟数据
        #send_result 参数: 是否成功,回馈内容,data 对象
        lewei_socket.send_result(True,"ok")
    elif obj["f"]=='getAllSensors': #接收到获取所有设备指令
        print 'recv getAllSensors command ,  send result!!!'
        #发送模拟数据
        lewei_socket.send_result(True,"ok",
                            [\
                            {"id":"switch1","type":"SWITCH",
                            "name":"switch1","value":1,"status":"ok"},\
                            {"id":"switch2","type":"SWITCH",\
                            "name":"switch2","value":1,"status":"ok"}\
                            ] )
#参数:乐联服务器地址,端口,用户Key,网关号,服务端发过来的消息回调函数
s = leweisocket(host,port,userkey,gatewayNo,msg_handler)
if  not s.connect():
    sys.exit()
s.run()

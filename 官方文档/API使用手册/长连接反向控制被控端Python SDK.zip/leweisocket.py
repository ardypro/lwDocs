# coding=utf-8
__author__ = 'wuyong'


import socket
import sys
import threading
import time
import json

class timer(threading.Thread):
    def __init__(self,interval,func):
        threading.Thread.__init__(self)
        self.thread_num = 1
        self.interval = interval
        self.thread_stop = False
        self.call_fun = func
    def run(self):
        while not self.thread_stop:
            apply(self.call_fun)
            time.sleep(self.interval)
    def stop(self):
        self.thread_stop = True

#socket
class leweisocket:
    def __init__(self,host,port,userkey,gatewayNo,msg_func=None):
        self.host_ = host
        self.port_ = port
        self.timer_ = timer(10,self.timer_hander)
        self.connected_ = False
        self.connected_cnt_ = 0
        self.userkey_ = userkey
        self.gatewayNo_ = gatewayNo
        self.msg_func_ = msg_func

    def timer_hander(self):
        if self.connected_:
            self.send_alive()

    def send_alive(self):
        json_str = "{\
                    \"method\": \"update\",\
                    \"gatewayNo\": \"" + self.gatewayNo_ +"\",\
                    \"userkey\": \"" + self.userkey_ + "\"\
                    }&^!"
        self.socket_.sendall( json_str )


    def connect(self):
        self.buffer_ = ''
        try:
            self.socket_ = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        except socket.error,msg:
            print 'Fail to create socket. Error code: ' + str(msg[0]) 
            return False

        print 'socket created'
        try:
            remote_ip = socket.gethostbyname(self.host_)
        except socket.gaierror:
            print 'Hostname could net be resolved . Exiting'
            return False

        print 'Ip address of ' + self.host_ + ' is ' + remote_ip

        try:
            self.socket_.connect( (remote_ip,self.port_) )
        except socket.error as msg:
            print 'Fail to connect remote host. (' + \
            remote_ip + ':' + str(self.port_) + ') Error code: ' + str(msg[0])
            return False
        print 'lewei server connect success'

        self.connected_ = True
        self.connected_cnt_ += 1
        if self.connected_cnt_==1:
            self.timer_.start()

        return True

    def reconnect(self):
        if not self.socket_ is None:
            self.socket_.close()
            del self.socket_
        if not self.connect():
            print 'after the 10s reconnect remote host'
            time.sleep(10)
            self.reconnect()
        else: return True
    def msg_handler(self,msg):
        if self.msg_func_!=None:
            obj = json.loads(msg)
            apply(self.msg_func_,(self,obj,msg),)
    #参数: 是否成功,消息,data 对象
    def send_result(self,successful,message,data=None):
        if self.connected_:
            data_json_str = ""
            if data!=None:
                data_json_str = "  ,\"data\":" + json.dumps(data)
            json_str = "{\"method\":\"response\",\
                                \"result\": {\
                                    \"successful\":" \
                                    + ( 'true' if successful else 'false' ) + ",\
                                    \"message\": \""  + message + "\""  \
                                    + data_json_str + "}\
                        }&^!"
            self.socket_.sendall(json_str)
    def run(self):
        while(1):
            data =  self.socket_.recv(1024)
            if ( len(data)==0 ): 
                self.connected_ = False
                print '!!! net break, after the 10s reconnect remote host'
                time.sleep(10)
                self.reconnect()
            else:
                self.buffer_ += data
                index = self.buffer_.find('&^!')
                msg = self.buffer_[:index]
                self.buffer_ = self.buffer_[index+3:]
                self.msg_handler( msg )
        self.timer_.stop()

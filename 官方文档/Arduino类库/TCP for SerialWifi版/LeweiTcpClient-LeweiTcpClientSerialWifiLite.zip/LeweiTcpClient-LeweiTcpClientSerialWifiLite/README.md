LeweiTcpClient
==============
This is the the version working for serial-wifi shield from LeweiTcpClient,this version were tested on arduino UNO.

Using this library is the one of the most easiest way to

keep connected to www.lewei50.com to store your data and make your arduino "controllable" from the Internet/your Smart Phone.

Now,only 3 steps between you and your arduino controllable:

step1:define your apikey and gateway number in your .ino file.

step2:copy this line into your loop() function,client->keepOnline();

step3:bind your function you write in arduino to the name you defined on website.

(check more detail in the example file.)

then it's all under your controll.

Also you can taste the normal version for your serial-wifi shield here:

https://github.com/lewei50/LeweiTcpClient/

This version can only accept 0/1/2 parameter(s) from the website you defined on it.
the normal version can accecpt 0/1/2/3/4/5 parameter(s).
Enjoy it~

Email:gyangbo@gmail.com
